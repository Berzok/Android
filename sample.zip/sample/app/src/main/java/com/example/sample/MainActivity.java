package com.example.sample;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

//Programme HelloWorld version 1, version de base
public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private TextView welcome = null;
    private TextView texte;
    private String mots[] = {"Nicolas Cage", "The Cake is a Lie", "Hello world", "Sweet Potato"};
    private Button leBouton1;
    private Button leBouton2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

	    setContentView(R.layout.activity_main);

		leBouton1 = (Button) findViewById(R.id.boutonExo8);
		leBouton1.setOnClickListener(this);
		leBouton2 = findViewById(R.id.boutonExo9);
		leBouton2.setOnClickListener(this);

        welcome = new TextView(this);

        welcome.setText("Hello everyone");
        TextView texte = findViewById(R.id.textView);
        texte.setVisibility(View.VISIBLE);


        //setContentView(texte);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void showDesc(View vue){
	    texte = findViewById(R.id.textView);
	    Random alea = new Random();
	    texte.setText(mots[alea.nextInt(4)]);

    }

	@Override
	public void onClick(View v) {
    	if(v == leBouton1){
	    	Intent laIntent = new Intent(v.getContext(), Exo8.class);
		    startActivity(laIntent);
	    }if(v == leBouton2){
    		Intent laIntent = new Intent(v.getContext(), Exo9.class);
			startActivity(laIntent);
		}


	}
}
