package com.example.sample;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.support.v7.app.AppCompatActivity;

public class Exo8 extends AppCompatActivity implements View.OnClickListener{
	private Button leBouton1;
	private Button leBouton2;
	private Button leBouton3;
	private TextView leTexte;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_exo8);

		leTexte = (TextView) findViewById(R.id.textViewExo8);

		leBouton1 = (Button) findViewById(R.id.button1);
		leBouton1.setOnClickListener(this);

		leBouton2 = (Button) findViewById(R.id.button2);
		leBouton2.setOnClickListener(this);

		leBouton3 = (Button) findViewById(R.id.button3);
		leBouton3.setOnClickListener(this);



		//setContentView(texte);

	}

	@Override
	public void onClick(View v) {
		if(v==leBouton1) {
			leTexte.setText(leBouton2.getText().toString());
		}if(v==leBouton2){
			leTexte.setText(leBouton3.getText().toString());
		}if(v==leBouton3){
			leTexte.setText(leBouton1.getText().toString());
		}
	}
}
