package com.example.sample;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class Exo9 extends AppCompatActivity  {
	private Button leBouton1;
	private Button leBouton2;
	private Button leBouton3;
	private TextView leTexte;
	int seconds;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_exo9);
		leTexte = findViewById(R.id.duration);
		runTimer();

	}
	private void runTimer(){
		final TextView timeView = (TextView)findViewById(R.id.duration);
		final Handler handler=new Handler();
		Timer T = new Timer();
		T.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				int hours=seconds/3600;
				int minutes=(seconds%3600)/60;
				int secs=seconds%60;
				String time = String.format("d:%02d:%02d",hours,minutes,secs);
				timeView.setText(time);
				handler.postDelayed(this,1000);
				seconds++;
			}
		}, 0, 1000);
	}//runTimer
}
